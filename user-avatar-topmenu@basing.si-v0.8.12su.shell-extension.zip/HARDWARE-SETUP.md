# Personal SU hardware setup

The SU package is publicly downloadable and is not an EGO package. It requires
the separately installed, exact-model g5-control or g6-control helper and the
keyboard LED driver. It does not install a driver or change system policy.

The two-second fade uses intermediate brightness levels from 0 through 255.
An old sudo rule permitting only 64, 128, and 255 must be extended. Install the
following using `sudo visudo -f /etc/sudoers.d/gse-keyboard-fade`, replacing
YOUR_USER with your desktop username and choosing ONLY the helper installed
for your laptop. The regular expression requires sudo 1.9.10 or newer:

G5 GD:
```sudoers
YOUR_USER ALL=(root) NOPASSWD: /usr/local/sbin/g5-control ^keyboard (cyan|green|white|blue|red) ([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])$
```

G6 KF:
```sudoers
YOUR_USER ALL=(root) NOPASSWD: /usr/local/sbin/g6-control ^keyboard (green|white|blue|red) ([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])$
```

Keep the existing validated `keyboard off`, `auto`, and bounded fan-test rules.
Validate the file using `sudo visudo -cf /etc/sudoers.d/gse-keyboard-fade` and
set ownership root:root and permissions 0440. Each helper must be root-owned
and must validate its exact DMI profile and numeric arguments.

No fan settings are changed by keyboard fading. Keep Awake remains independent.
After upgrading, log out/in. Select a short timeout in Hardware Preferences:
the light fades during the next two seconds, reaches zero, and input restores
its previous color and brightness. Without the updated rule, intermediate
brightness commands are rejected; update policy before testing the fade.
