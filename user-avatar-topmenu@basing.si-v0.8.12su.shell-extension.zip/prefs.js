import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Gtk from 'gi://Gtk';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';
import {createGigabyteHardwarePage} from './lib/gigabyteHardwarePrefs.js';

export default class UsernameAvatarPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const _ = this.gettext.bind(this);
        const settings = this.getSettings();
        const version = this._getDisplayVersion();
        const desktopInterfaceSettings = new Gio.Settings({schema: 'org.gnome.desktop.interface'});
        const touchpadSettings = new Gio.Settings({schema: 'org.gnome.desktop.peripherals.touchpad'});

        window.set_default_size(700, 620);

        const generalPage = new Adw.PreferencesPage({
            title: _('General'),
            icon_name: 'avatar-default-symbolic',
        });
        const generalGroup = new Adw.PreferencesGroup({
            title: this.gettext('Label'),
            description: this.gettext('Choose what text appears next to the avatar in the top bar.'),
        });

        const showHostRow = new Adw.SwitchRow({
            title: this.gettext('Include computer name'),
            subtitle: this.gettext('Shows a computer icon with the hostname, for example "John on myPC".'),
        });

        settings.bind(
            'show-hostname',
            showHostRow,
            'active',
            Gio.SettingsBindFlags.DEFAULT
        );

        const showUsernameRow = new Adw.SwitchRow({
            title: this.gettext('Display name'),
            subtitle: this.gettext('Controls whether the account real/display name is shown in the top bar.'),
        });

        settings.bind(
            'show-username',
            showUsernameRow,
            'active',
            Gio.SettingsBindFlags.DEFAULT
        );

        const showAvatarRow = new Adw.SwitchRow({
            title: this.gettext('Display avatar'),
            subtitle: this.gettext('Controls whether the user avatar is shown in the top bar.'),
        });

        settings.bind(
            'show-avatar',
            showAvatarRow,
            'active',
            Gio.SettingsBindFlags.DEFAULT
        );

        const placeAfterNavigationRow = new Adw.SwitchRow({
            title: this.gettext('Place after Apps and Places'),
            subtitle: this.gettext('When enabled, the panel item moves after those menus if they are present.'),
        });

        settings.bind(
            'place-after-navigation',
            placeAfterNavigationRow,
            'active',
            Gio.SettingsBindFlags.DEFAULT
        );

        const showTopBarRow = new Adw.SwitchRow({
            title: this.gettext('Show in top bar'),
            subtitle: this.gettext('Disable this if you only want the quick settings menu entry.'),
        });

        settings.bind(
            'show-topbar',
            showTopBarRow,
            'active',
            Gio.SettingsBindFlags.DEFAULT
        );

        const showQuickSettingsRow = new Adw.SwitchRow({
            title: this.gettext('Show in quick settings'),
            subtitle: this.gettext('Controls whether the username tile appears in the right-side quick settings menu.'),
        });

        settings.bind(
            'show-quick-settings',
            showQuickSettingsRow,
            'active',
            Gio.SettingsBindFlags.DEFAULT
        );

        generalGroup.add(showHostRow);
        generalGroup.add(showUsernameRow);
        generalGroup.add(showAvatarRow);
        generalGroup.add(placeAfterNavigationRow);
        generalGroup.add(showTopBarRow);
        generalGroup.add(showQuickSettingsRow);
        generalPage.add(generalGroup);

        const desktopPage = new Adw.PreferencesPage({
            title: _('Desktop'),
            icon_name: 'preferences-desktop-symbolic',
        });
        const desktopGroup = new Adw.PreferencesGroup({
            title: this.gettext('Desktop Behavior'),
            description: this.gettext('Quick access to a couple of GNOME desktop defaults that many Fedora 44 and GNOME 50 users want to turn back on.'),
        });

        const primaryPasteRow = new Adw.SwitchRow({
            title: this.gettext('Enable primary paste'),
            subtitle: this.gettext('Restores middle-click paste from selected text by setting gtk-enable-primary-paste.'),
        });
        primaryPasteRow.active = desktopInterfaceSettings.get_boolean('gtk-enable-primary-paste');
        primaryPasteRow.connect('notify::active', row => {
            if (desktopInterfaceSettings.get_boolean('gtk-enable-primary-paste') !== row.active)
                desktopInterfaceSettings.set_boolean('gtk-enable-primary-paste', row.active);
        });
        desktopInterfaceSettings.connect('changed::gtk-enable-primary-paste', () => {
            primaryPasteRow.active = desktopInterfaceSettings.get_boolean('gtk-enable-primary-paste');
        });

        const touchpadMiddleClickRow = new Adw.SwitchRow({
            title: this.gettext('Three-finger middle click'),
            subtitle: this.gettext('Sets the touchpad tap button map to lrm so three-finger tap acts as middle click.'),
        });
        touchpadMiddleClickRow.active = touchpadSettings.get_string('tap-button-map') === 'lrm';
        touchpadMiddleClickRow.connect('notify::active', row => {
            const current = touchpadSettings.get_string('tap-button-map');
            if (row.active) {
                if (current !== 'lrm')
                    settings.set_string('touchpad-previous-map', current);
                touchpadSettings.set_string('tap-button-map', 'lrm');
            } else if (current === 'lrm') {
                touchpadSettings.set_string(
                    'tap-button-map',
                    settings.get_string('touchpad-previous-map') || 'default'
                );
                settings.set_string('touchpad-previous-map', '');
            }
        });
        touchpadSettings.connect('changed::tap-button-map', () => {
            touchpadMiddleClickRow.active = touchpadSettings.get_string('tap-button-map') === 'lrm';
        });

        desktopGroup.add(primaryPasteRow);
        desktopGroup.add(touchpadMiddleClickRow);
        desktopPage.add(desktopGroup);

        const loadsPage = new Adw.PreferencesPage({
            title: _('System Loads'),
            icon_name: 'power-profile-performance-symbolic',
        });
        const loadsGroup = new Adw.PreferencesGroup({
            title: this.gettext('System Loads'),
            description: this.gettext('Choose which live usage columns are shown in the top bar.'),
        });
        const loadsPositionRow = new Adw.ComboRow({
            title: this.gettext('Display position'),
            subtitle: this.gettext('Left shows loads after the user item; right shows loads before the system icons.'),
            model: Gtk.StringList.new([_('Left side'), _('Right side')]),
            selected: settings.get_string('loads-position') === 'right' ? 1 : 0,
        });
        loadsPositionRow.connect('notify::selected', row => {
            settings.set_string('loads-position', row.selected === 1 ? 'right' : 'left');
        });
        loadsGroup.add(loadsPositionRow);
        this._addPollingIntervalRow(loadsGroup, settings, 'loads-refresh-seconds', this.gettext('Usage polling interval'), this.gettext('Seconds between CPU, memory, swap, and GPU usage updates.'), 30);
        this._addBoundSwitch(loadsGroup, settings, 'show-load-cpu', this.gettext('CPU usage'), this.gettext('Shows CPU load as a percentage column.'));
        this._addBoundSwitch(loadsGroup, settings, 'show-load-mem', this.gettext('Memory usage'), this.gettext('Shows memory utilization with used and total memory in the tooltip.'));
        this._addBoundSwitch(loadsGroup, settings, 'show-load-swap', this.gettext('Swap usage'), this.gettext('Shows swap utilization when swap is configured.'));
        this._addBoundSwitch(loadsGroup, settings, 'show-load-igpu', this.gettext('Integrated GPU usage'), this.gettext('Shows iGPU usage and memory details when exposed by the driver.'));
        this._addBoundSwitch(loadsGroup, settings, 'show-load-dgpu', this.gettext('Discrete GPU usage'), this.gettext('Shows dGPU usage and memory details when exposed by the driver.'));
        this._addBoundSwitch(loadsGroup, settings, 'show-load-network', this.gettext('Network throughput'), this.gettext('Shows aggregate download speed with upload speed in the tooltip.'));
        this._addBoundSwitch(loadsGroup, settings, 'show-load-disk', this.gettext('Disk activity'), this.gettext('Shows aggregate physical-disk read speed with write speed in the tooltip.'));
        this._addBoundSwitch(loadsGroup, settings, 'use-load-colors', this.gettext('Use colored usage icons'), this.gettext('Disable this to show usage icons and bars in the default white panel color.'));
        this._addOrderRows(loadsGroup, settings, 'metric-order', ['cpu', 'mem', 'swap', 'igpu', 'dgpu', 'network', 'disk']);
        this._addBoundSwitch(loadsGroup, settings, 'compact-metrics', this.gettext('Compact metrics'), this.gettext('Reduce panel spacing when many metrics are enabled.'));
        loadsPage.add(loadsGroup);

        const deviceGroup = new Adw.PreferencesGroup({
            title: this.gettext('GPU Devices'),
            description: this.gettext('Override automatic GPU classification when a hybrid or AMD-only system is detected incorrectly.'),
        });
        const gpuChoices = this._getGpuChoices();
        this._addDeviceRow(deviceGroup, settings, 'igpu-device', this.gettext('Integrated GPU'), gpuChoices);
        this._addDeviceRow(deviceGroup, settings, 'dgpu-device', this.gettext('Discrete GPU'), gpuChoices);
        this._addPollingIntervalRow(deviceGroup, settings, 'nvidia-index', this.gettext('NVIDIA GPU index'), this.gettext('Zero-based nvidia-smi device index for systems with multiple NVIDIA GPUs.'), 15, 0);
        loadsPage.add(deviceGroup);

        const networkGroup = new Adw.PreferencesGroup({
            title: this.gettext('Network Device'),
            description: this.gettext('Automatic aggregates physical network interfaces and avoids double-counting virtual bridges.'),
        });
        this._addDeviceRow(networkGroup, settings, 'network-interface', this.gettext('Network interface'), this._getNetworkChoices());
        const networkMode = new Adw.ComboRow({title: _('Automatic network mode'),
            subtitle: _('Physical devices, or independent bridge/VLAN endpoints. Select a VPN interface explicitly to measure VPN traffic.'),
            model: Gtk.StringList.new([_('Physical devices'), _('Aggregate endpoints')]),
            selected: settings.get_string('network-mode') === 'aggregate' ? 1 : 0});
        networkMode.connect('notify::selected', () => settings.set_string('network-mode', networkMode.selected ? 'aggregate' : 'physical'));
        settings.connect('changed::network-mode', () => { networkMode.selected = settings.get_string('network-mode') === 'aggregate' ? 1 : 0; });
        networkGroup.add(networkMode);
        loadsPage.add(networkGroup);

        const performanceGroup = new Adw.PreferencesGroup({
            title: this.gettext('Performance and Power'),
            description: this.gettext('Polling stops while locked and slows down on battery by default.'),
        });
        this._addBoundSwitch(performanceGroup, settings, 'pause-metrics-when-locked', this.gettext('Pause while locked'), this.gettext('Avoids unnecessary hardware polling on the lock screen.'));
        this._addBoundSwitch(performanceGroup, settings, 'adaptive-refresh-on-battery', this.gettext('Reduce polling on battery'), this.gettext('Uses a longer interval while UPower reports battery operation.'));
        this._addPollingIntervalRow(performanceGroup, settings, 'battery-refresh-multiplier', this.gettext('Battery interval multiplier'), this.gettext('Multiplier applied to normal metric polling intervals.'), 10, 2);
        const clickActionRow = new Adw.ComboRow({
            title: this.gettext('Metric click action'),
            subtitle: this.gettext('Choose what happens when a metric is clicked or keyboard-activated.'),
            model: Gtk.StringList.new([_('Open System Monitor'), _('Do nothing')]),
            selected: settings.get_string('metrics-click-action') === 'none' ? 1 : 0,
        });
        clickActionRow.connect('notify::selected', row => {
            settings.set_string('metrics-click-action', row.selected === 1 ? 'none' : 'system-monitor');
        });
        performanceGroup.add(clickActionRow);
        loadsPage.add(performanceGroup);

        const tempsPage = new Adw.PreferencesPage({
            title: _('Temperatures'),
            icon_name: 'temperature-symbolic',
        });
        const tempsGroup = new Adw.PreferencesGroup({
            title: this.gettext('Temperatures'),
            description: this.gettext('Choose which live temperature columns are shown in the top bar.'),
        });
        const tempsPositionRow = new Adw.ComboRow({
            title: this.gettext('Display position'),
            subtitle: this.gettext('Left shows temperatures after loads; right shows temperatures before loads.'),
            model: Gtk.StringList.new([_('Left side'), _('Right side')]),
            selected: settings.get_string('temps-position') === 'right' ? 1 : 0,
        });
        tempsPositionRow.connect('notify::selected', row => {
            settings.set_string('temps-position', row.selected === 1 ? 'right' : 'left');
        });
        tempsGroup.add(tempsPositionRow);
        this._addPollingIntervalRow(tempsGroup, settings, 'temps-refresh-seconds', this.gettext('Temperature polling interval'), this.gettext('Seconds between CPU and GPU temperature updates.'), 60);
        const temperatureUnitRow = new Adw.ComboRow({
            title: this.gettext('Temperature unit'),
            subtitle: this.gettext('Choose Celsius or Fahrenheit for panel values and tooltips.'),
            model: Gtk.StringList.new([_('Celsius (°C)'), _('Fahrenheit (°F)')]),
            selected: settings.get_string('temperature-unit') === 'fahrenheit' ? 1 : 0,
        });
        temperatureUnitRow.connect('notify::selected', row => {
            settings.set_string('temperature-unit', row.selected === 1 ? 'fahrenheit' : 'celsius');
        });
        tempsGroup.add(temperatureUnitRow);
        this._addBoundSwitch(tempsGroup, settings, 'temperature-decimals', this.gettext('Show decimal values'), this.gettext('Shows one decimal place for temperatures when the sensor provides it.'));
        this._addBoundSwitch(tempsGroup, settings, 'show-temp-cpu', this.gettext('CPU temperature'), this.gettext('Shows the CPU package temperature when available.'));
        this._addBoundSwitch(tempsGroup, settings, 'show-temp-igpu', this.gettext('Integrated GPU temperature'), this.gettext('Shows iGPU temperature when available.'));
        this._addBoundSwitch(tempsGroup, settings, 'show-temp-dgpu', this.gettext('Discrete GPU temperature'), this.gettext('Shows dGPU temperature when available.'));
        this._addBoundSwitch(tempsGroup, settings, 'use-temp-colors', this.gettext('Use colored temperature icons'), this.gettext('Disable this to show temperature icons and values in the default white panel color.'));
        const warningSpin = this._addPollingIntervalRow(tempsGroup, settings, 'temp-warning', this.gettext('Warning threshold'), this.gettext('Temperature in Celsius where the orange warning color begins.'), 100, 30);
        const criticalSpin = this._addPollingIntervalRow(tempsGroup, settings, 'temp-critical', this.gettext('Critical threshold'), this.gettext('Temperature in Celsius where the red critical color begins.'), 120, 40);
        warningSpin.connect('value-changed', () => {
            if (warningSpin.get_value_as_int() >= criticalSpin.get_value_as_int())
                criticalSpin.set_value(Math.min(120, warningSpin.get_value_as_int() + 5));
        });
        criticalSpin.connect('value-changed', () => {
            if (criticalSpin.get_value_as_int() <= warningSpin.get_value_as_int())
                warningSpin.set_value(Math.max(30, criticalSpin.get_value_as_int() - 5));
        });
        this._addOrderRows(tempsGroup, settings, 'temp-order', ['cpu', 'igpu', 'dgpu']);
        tempsPage.add(tempsGroup);

        const awakePage = new Adw.PreferencesPage({
            title: _('Keep Awake'),
            icon_name: 'weather-clear-symbolic',
        });
        const awakeGroup = new Adw.PreferencesGroup({
            title: this.gettext('Keep Awake'),
            description: this.gettext('Prevent the session from going idle while the toggle is enabled.'),
        });
        const keepAwakeRow = new Adw.SwitchRow({
            title: this.gettext('Block screen saver'),
            subtitle: this.gettext('Shows a colored sun icon in the panel while active and also appears in the user submenu.'),
        });
        settings.bind(
            'keep-awake',
            keepAwakeRow,
            'active',
            Gio.SettingsBindFlags.DEFAULT
        );
        awakeGroup.add(keepAwakeRow);
        this._addBoundSwitch(awakeGroup, settings, 'keep-awake-fullscreen', this.gettext('Automatic for fullscreen apps'), this.gettext('Keeps the session awake while the focused app is fullscreen.'));
        this._addBoundSwitch(awakeGroup, settings, 'keep-awake-media', this.gettext('Automatic while media is playing'), this.gettext('Keeps the session awake while an MPRIS-compatible app reports playback.'));
        awakePage.add(awakeGroup);

        const timerGroup = new Adw.PreferencesGroup({
            title: this.gettext('Timer'),
            description: this.gettext('Temporarily keep the session awake, then turn the timer off automatically.'),
        });
        const timerDurations = [15, 30, 60, 120];
        const timerMinutes = settings.get_uint('keep-awake-timer-minutes');
        const timerDurationRow = new Adw.ComboRow({
            title: this.gettext('Duration'),
            subtitle: this.gettext('Duration used whenever the timer is started.'),
            model: Gtk.StringList.new([_('15 minutes'), _('30 minutes'), _('1 hour'), _('2 hours')]),
            selected: Math.max(0, timerDurations.indexOf(timerMinutes)),
        });
        timerDurationRow.connect('notify::selected', row => {
            settings.set_uint('keep-awake-timer-minutes', timerDurations[row.selected] ?? 30);
        });
        timerGroup.add(timerDurationRow);
        this._addBoundSwitch(timerGroup, settings, 'keep-awake-timer-active', 'Start keep-awake timer', 'Switch off to cancel early; it also switches off automatically when time expires.');
        awakePage.add(timerGroup);

        const autohidePage = new Adw.PreferencesPage({
            title: _('Autohide'),
            icon_name: 'view-fullscreen-symbolic',
        });
        const autohideGroup = new Adw.PreferencesGroup({
            title: this.gettext('Top Bar Autohide'),
            description: this.gettext('Choose when the GNOME top bar should hide automatically.'),
        });
        const hideInFullscreenRow = new Adw.SwitchRow({
            title: this.gettext('Hide in fullscreen'),
            subtitle: this.gettext('Hide the top bar whenever the focused app is fullscreen.'),
        });
        settings.bind(
            'hide-topbar-fullscreen',
            hideInFullscreenRow,
            'active',
            Gio.SettingsBindFlags.DEFAULT
        );
        const hideFullscreenAllMonitorsRow = new Adw.SwitchRow({
            title: this.gettext('Fullscreen on all monitors'),
            subtitle: this.gettext('When enabled, fullscreen autohide applies to focused fullscreen windows on any monitor, not only the primary one.'),
        });
        settings.bind(
            'hide-topbar-fullscreen-all-monitors',
            hideFullscreenAllMonitorsRow,
            'active',
            Gio.SettingsBindFlags.DEFAULT
        );
        const syncFullscreenDependency = () => {
            hideFullscreenAllMonitorsRow.sensitive = settings.get_boolean('hide-topbar-fullscreen');
        };
        settings.connect('changed::hide-topbar-fullscreen', syncFullscreenDependency);
        const hideMaximizedRow = new Adw.SwitchRow({
            title: this.gettext('Hide when maximized'),
            subtitle: this.gettext('Hide the top bar whenever the focused window is maximized.'),
        });
        settings.bind(
            'hide-topbar-maximized',
            hideMaximizedRow,
            'active',
            Gio.SettingsBindFlags.DEFAULT
        );
        const hideTouchingRow = new Adw.SwitchRow({
            title: this.gettext('Hide when touching top bar'),
            subtitle: this.gettext('Hide the top bar whenever the focused window reaches the top edge of the screen.'),
        });
        settings.bind(
            'hide-topbar-touching',
            hideTouchingRow,
            'active',
            Gio.SettingsBindFlags.DEFAULT
        );
        autohideGroup.add(hideInFullscreenRow);
        autohideGroup.add(hideFullscreenAllMonitorsRow);
        autohideGroup.add(hideMaximizedRow);
        autohideGroup.add(hideTouchingRow);
        syncFullscreenDependency();
        autohidePage.add(autohideGroup);

        const diagnosticsPage = new Adw.PreferencesPage({
            title: _('Diagnostics'),
            icon_name: 'preferences-system-symbolic',
        });
        const diagnosticsGroup = new Adw.PreferencesGroup({
            title: this.gettext('Detected Hardware'),
            description: this.gettext('Read-only local information used by the extension. No data is transmitted.'),
        });
        for (const [title, subtitle] of this._getDiagnostics(settings))
            diagnosticsGroup.add(new Adw.ActionRow({title, subtitle}));
        diagnosticsPage.add(diagnosticsGroup);

        const resetGroup = new Adw.PreferencesGroup({
            title: this.gettext('Reset'),
            description: this.gettext('Restore every extension preference to its schema default.'),
        });
        const resetRow = new Adw.ActionRow({
            title: this.gettext('Reset extension settings'),
            subtitle: this.gettext('Desktop-wide primary-paste and touchpad settings are not reset.'),
        });
        const resetButton = new Gtk.Button({
            label: this.gettext('Reset to Defaults'),
            valign: Gtk.Align.CENTER,
            css_classes: ['destructive-action'],
        });
        resetButton.connect('clicked', () => {
            for (const key of settings.list_keys())
                if (key !== 'touchpad-previous-map')
                    settings.reset(key);
        });
        resetRow.add_suffix(resetButton);
        resetRow.activatable_widget = resetButton;
        resetGroup.add(resetRow);
        diagnosticsPage.add(resetGroup);

        const aboutPage = new Adw.PreferencesPage({
            title: _('About'),
            icon_name: 'help-about-symbolic',
        });
        const infoGroup = new Adw.PreferencesGroup({
            title: this.gettext('About'),
        });
        const descriptionRow = new Adw.ActionRow({
            title: this.gettext('Description'),
            subtitle: this.metadata.description,
        });
        const authorRow = new Adw.ActionRow({
            title: this.gettext('Author'),
            subtitle: this.gettext('Denis Zvegelj, 2026'),
        });
        const licenseRow = new Adw.ActionRow({
            title: this.gettext('License'),
            subtitle: this.gettext('GNU GPL v3'),
        });
        const versionRow = new Adw.ActionRow({
            title: this.gettext('Installed version'),
            subtitle: version,
        });
        infoGroup.add(descriptionRow);
        infoGroup.add(authorRow);
        infoGroup.add(licenseRow);
        infoGroup.add(versionRow);
        aboutPage.add(infoGroup);

        const supportGroup = new Adw.PreferencesGroup({
            title: this.gettext('Support'),
        });
        const supportRow = new Adw.ActionRow({
            title: this.gettext('Support further development'),
            subtitle: this.gettext('If this extension is useful, you can support future development on idz.si.'),
        });
        const supportButton = Gtk.LinkButton.new_with_label(
            'https://idz.si/bs/gse-user-avatar-topmenu-donate.html',
            'Open Donation Page'
        );
        supportRow.add_suffix(supportButton);
        supportRow.activatable_widget = supportButton;
        supportGroup.add(supportRow);
        aboutPage.add(supportGroup);

        window.add(generalPage);
        window.add(loadsPage);
        window.add(awakePage);
        window.add(desktopPage);
        window.add(tempsPage);
        window.add(autohidePage);
        const hardwarePage = createGigabyteHardwarePage(_, settings);
        if (hardwarePage)
            window.add(hardwarePage);
        window.add(diagnosticsPage);
        window.add(aboutPage);
        this._localizeWidgetTree(window, _);
    }

    _addOrderRows(group, settings, key, allowed) {
        const groupRows = [];
        const rebuild = () => {
            for (const row of groupRows) group.remove(row);
            groupRows.length = 0;
            const order = [...new Set([...settings.get_string(key).split(',').map(id => id.trim()), ...allowed])]
                .filter(id => allowed.includes(id));
            order.forEach((id, index) => {
                const row = new Adw.ActionRow({title: this.gettext(id.toUpperCase())});
                for (const [delta, icon, title] of [[-1, 'go-up-symbolic', 'Move up'], [1, 'go-down-symbolic', 'Move down']]) {
                    const button = new Gtk.Button({icon_name: icon, tooltip_text: this.gettext(title),
                        valign: Gtk.Align.CENTER, sensitive: index + delta >= 0 && index + delta < order.length});
                    button.connect('clicked', () => {
                        const next = [...order];
                        [next[index], next[index + delta]] = [next[index + delta], next[index]];
                        settings.set_string(key, next.join(','));
                    });
                    row.add_suffix(button);
                }
                group.add(row); groupRows.push(row);
            });
        };
        settings.connect(`changed::${key}`, rebuild);
        rebuild();
    }

    _addBoundSwitch(group, settings, key, title, subtitle) {
        const row = new Adw.SwitchRow({
            title: this.gettext(title),
            subtitle: this.gettext(subtitle),
        });
        settings.bind(key, row, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(row);
    }

    _addPollingIntervalRow(group, settings, key, title, subtitle, upper, lower = 1) {
        const row = new Adw.ActionRow({
            title: this.gettext(title),
            subtitle: this.gettext(subtitle),
        });
        const adjustment = new Gtk.Adjustment({
            lower,
            upper,
            step_increment: 1,
            page_increment: 5,
            value: settings.get_uint(key),
        });
        const spin = new Gtk.SpinButton({
            adjustment,
            digits: 0,
            valign: Gtk.Align.CENTER,
        });
        spin.connect('value-changed', widget => {
            settings.set_uint(key, widget.get_value_as_int());
        });
        settings.connect(`changed::${key}`, () => {
            const value = settings.get_uint(key);
            if (spin.get_value_as_int() !== value)
                spin.set_value(value);
        });
        row.add_suffix(spin);
        row.activatable_widget = spin;
        group.add(row);
        return spin;
    }

    _getGpuChoices() {
        const choices = [{id: 'auto', label: this.gettext('Automatic')}];
        try {
            const directory = Gio.File.new_for_path('/sys/class/drm');
            const enumerator = directory.enumerate_children(
                'standard::name', Gio.FileQueryInfoFlags.NONE, null);
            let info;
            while ((info = enumerator.next_file(null))) {
                const name = info.get_name();
                if (/^card\d+$/.test(name) &&
                    GLib.file_test(`/sys/class/drm/${name}/device`, GLib.FileTest.IS_DIR))
                    choices.push({id: name, label: name});
            }
            enumerator.close(null);
        } catch (_error) {
            // Keep the automatic choice when sysfs is unavailable.
        }
        return choices;
    }

    _getNetworkChoices() {
        const choices = [{id: 'auto', label: this.gettext('Automatic physical interfaces')}];
        try {
            const enumerator = Gio.File.new_for_path('/sys/class/net').enumerate_children(
                'standard::name', Gio.FileQueryInfoFlags.NONE, null);
            let info;
            while ((info = enumerator.next_file(null))) {
                const name = info.get_name();
                if (name !== 'lo')
                    choices.push({id: name, label: name});
            }
            enumerator.close(null);
        } catch (_error) {
            // Keep the automatic choice.
        }
        return choices;
    }

    _addDeviceRow(group, settings, key, title, choices) {
        const current = settings.get_string(key);
        if (!choices.some(choice => choice.id === current))
            choices = [...choices, {id: current, label: `${current} (unavailable)`}];
        const selected = Math.max(0, choices.findIndex(choice => choice.id === current));
        const row = new Adw.ComboRow({
            title: this.gettext(title),
            subtitle: this.gettext('Automatic is recommended unless the wrong GPU is shown.'),
            model: Gtk.StringList.new(choices.map(choice => this.gettext(choice.label))),
            selected,
        });
        row.connect('notify::selected', widget => {
            settings.set_string(key, choices[widget.selected]?.id ?? 'auto');
        });
        settings.connect(`changed::${key}`, () => {
            const index = choices.findIndex(choice => choice.id === settings.get_string(key));
            if (index >= 0 && row.selected !== index) row.selected = index;
        });
        group.add(row);
    }

    _getDiagnostics(settings) {
        const gpuNames = this._getGpuChoices().slice(1).map(choice => choice.label);
        const hwmon = [];
        try {
            const enumerator = Gio.File.new_for_path('/sys/class/hwmon').enumerate_children(
                'standard::name', Gio.FileQueryInfoFlags.NONE, null);
            let info;
            while ((info = enumerator.next_file(null))) {
                const directoryName = info.get_name();
                const nameFile = Gio.File.new_for_path(`/sys/class/hwmon/${directoryName}/name`);
                try {
                    const [ok, contents] = nameFile.load_contents(null);
                    hwmon.push(ok
                        ? new TextDecoder().decode(contents).trim()
                        : directoryName);
                } catch (_error) {
                    hwmon.push(directoryName);
                }
            }
            enumerator.close(null);
        } catch (_error) {
            // Report the empty state below.
        }
        const read = path => {
            try { return new TextDecoder().decode(Gio.File.new_for_path(path).load_contents(null)[1]).trim(); }
            catch (error) { return `Unavailable: ${error.message}`; }
        };
        const sources = [];
        try {
            const monitors = Gio.File.new_for_path('/sys/class/hwmon').enumerate_children('standard::name', Gio.FileQueryInfoFlags.NONE, null);
            let device;
            while ((device = monitors.next_file(null))) {
                const base = `/sys/class/hwmon/${device.get_name()}`;
                const files = Gio.File.new_for_path(base).enumerate_children('standard::name', Gio.FileQueryInfoFlags.NONE, null);
                let file;
                while ((file = files.next_file(null))) {
                    if (!/^temp\d+_input$/.test(file.get_name())) continue;
                    const path = `${base}/${file.get_name()}`;
                    const value = read(path);
                    sources.push([`${read(`${base}/name`)}: ${file.get_name()}`,
                        `${path}: ${Number.isFinite(Number(value)) ? `${Number(value) / 1000} °C` : value}`]);
                }
                files.close(null);
            }
            monitors.close(null);
        } catch (error) {
            sources.push(['Sensor access', error.message]);
        }
        for (const choice of this._getGpuChoices().slice(1)) {
            const base = `/sys/class/drm/${choice.id}/device`;
            sources.push([choice.id, `${base}; vendor ${read(`${base}/vendor`)}; device ${read(`${base}/device`)}`]);
        }
        const selected = settings.get_string('dgpu-device');
        return [
            ['Selected GPU', selected === 'auto' ? 'Automatic selection' :
                this._getGpuChoices().some(choice => choice.id === selected) ? selected : `${selected}: device is not present`],
            ['NVIDIA selection', `Index ${settings.get_uint('nvidia-index')}; unavailable indices are not replaced by GPU 0. Dormant drivers are not probed.`],
            ['CPU readings', '/sys/class/hwmon: coretemp/k10temp/zenpower labeled sensors; no unrelated storage-temperature fallback.'],
            ['Disk source', '/proc/diskstats: whole physical disks only; RAID/device-mapper/zram and partitions excluded.'],
            ['Network source', `/proc/net/dev; ${settings.get_string('network-interface')}; mode ${settings.get_string('network-mode')}`],
            ...sources,
            ['DRM devices', gpuNames.length ? gpuNames.join(', ') : 'No DRM cards detected'],
            ['Hardware monitors', hwmon.length ? [...new Set(hwmon)].join(', ') : 'No hwmon devices detected'],
            ['NVIDIA metrics', GLib.find_program_in_path('nvidia-smi') ? 'nvidia-smi is installed' : 'nvidia-smi is not installed'],
            ['Memory inventory', GLib.find_program_in_path('dmidecode') ? 'dmidecode is installed; access may be restricted' : 'dmidecode is not installed'],
        ];
    }

    _localizeWidgetTree(widget, gettext) {
        if (widget instanceof Adw.PreferencesPage || widget instanceof Adw.PreferencesGroup ||
            widget instanceof Adw.ActionRow || widget instanceof Adw.EntryRow) {
            if (widget.title)
                widget.title = gettext(widget.title);
        }
        if (widget instanceof Adw.PreferencesGroup && widget.description)
            widget.description = gettext(widget.description);
        if (widget instanceof Adw.ActionRow && widget.subtitle)
            widget.subtitle = gettext(widget.subtitle);
        if (widget instanceof Gtk.Button && widget.label)
            widget.label = gettext(widget.label);

        for (let child = widget.get_first_child?.(); child; child = child.get_next_sibling())
            this._localizeWidgetTree(child, gettext);
    }

    _getDisplayVersion() {
        const versionPath = GLib.build_filenamev([this.path, 'VERSION']);

        try {
            const [ok, contents] = Gio.File.new_for_path(versionPath).load_contents(null);

            if (ok)
                return new TextDecoder().decode(contents).trim();
        } catch (error) {
            console.debug(`Unable to read VERSION file: ${error.message}`);
        }

        return `metadata ${this.metadata.version}`;
    }
}
